import math

def volume(r):
    return (4 * math.pi * (r ** 3)) / 3

print(volume(2))
print(volume(4))
print(volume(6.7))