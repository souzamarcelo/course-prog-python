n1 = int(input('Primeiro número: '))
n2 = int(input('Segundo número: '))

if n1 > n2:
    print('O primeiro número é maior!')

if n2 > n1:
    print('O segundo número é maior!')

if n1 == n2:
    print('Os números são iguais!')