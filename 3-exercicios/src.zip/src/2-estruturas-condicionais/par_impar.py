n = int(input('Informe o número: '))

if n % 2 == 0:
    print('PAR')
else:
    print('ÍMPAR')