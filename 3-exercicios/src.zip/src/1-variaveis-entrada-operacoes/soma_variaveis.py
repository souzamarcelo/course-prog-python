a = 5
b = 3
c = -2

print('Soma:', a + b + c)