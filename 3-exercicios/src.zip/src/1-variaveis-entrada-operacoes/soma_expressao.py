# Calculando a expressão diretamente
print((2 * 3) + (3 * 5))

# Calculando a expressão usando variáveis
a = 3
b = 5
print((2 * a) + (3 * b))