metros = float(input('Valor em metros: '))
milimetros = metros * 1000

print('Em milimetros é:', milimetros)