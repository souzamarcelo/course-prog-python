altura1 = float(input('Altura da pessoa 1 (em m): '))
altura2 = float(input('Altura da pessoa 2 (em m): '))
altura3 = float(input('Altura da pessoa 3 (em m): '))
altura4 = float(input('Altura da pessoa 4 (em m): '))

media = (altura1 + altura2 + altura3 + altura4) / 4
print('Média:', media)