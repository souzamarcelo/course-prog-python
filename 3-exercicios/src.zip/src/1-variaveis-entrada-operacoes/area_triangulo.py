b = 6
h = 5
A = (b * h) / 2
print(A)