salario = 3600
percentual = 23/100

aumento = salario * percentual
novo_salario = salario + aumento

print('Aumento:', aumento)
print('Novo salário:', novo_salario)